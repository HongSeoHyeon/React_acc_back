package kr.co.seoulit.account.settlement.financialstatements.controller;

import kr.co.seoulit.account.settlement.financialstatements.service.FinancialStatementsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@CrossOrigin("*")
@RestController
@RequestMapping("/statement")
public class CashFlowStatementController {



}
