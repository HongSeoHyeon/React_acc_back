package kr.co.seoulit.account.sys.base.exception;

@SuppressWarnings("serial")
public class DeptCodeNotFoundException extends Exception {
    public DeptCodeNotFoundException(String msg) {
        super(msg);
    }
}
