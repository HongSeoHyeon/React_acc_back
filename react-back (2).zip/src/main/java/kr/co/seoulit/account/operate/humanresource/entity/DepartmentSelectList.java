package kr.co.seoulit.account.operate.humanresource.entity;

public interface DepartmentSelectList {
    String getWorkplaceCode();

    String getWorkplaceName();
}
