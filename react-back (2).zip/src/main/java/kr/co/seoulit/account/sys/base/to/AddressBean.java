package kr.co.seoulit.account.sys.base.to;

public class AddressBean {
    String zipNo;
    String zipcode;
    String sido;
    String sigungu;
    String dong;
    String ri;
    String bunji;
    String sidoname;
    String roadName;
    String buildingCode1;
    String buildingCode2;


    public String getRoadname() {
        return roadName;
    }

    public void setRoadname(String roadName) {
        this.roadName = roadName;
    }

    public String getBuildingcode1() {
        return buildingCode1;
    }

    public void setBuildingcode1(String buildingCode1) {
        this.buildingCode1 = buildingCode1;
    }

    public String getBuildingcode2() {
        return buildingCode2;
    }

    public void setBuildingcode2(String buildingCode2) {
        this.buildingCode2 = buildingCode2;
    }

    public String getZipNo() {
        return zipNo;
    }

    public void setZipNo(String zipNo) {
        this.zipNo = zipNo;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getSido() {
        return sido;
    }

    public void setSido(String sido) {
        this.sido = sido;
    }

    public String getSidoname() {
        return sidoname;
    }

    public void setSidoname(String sidoname) {
        this.sidoname = sidoname;
    }

    public String getSigungu() {
        return sigungu;
    }

    public void setSigungu(String sigungu) {
        this.sigungu = sigungu;
    }

    public String getDong() {
        return dong;
    }

    public void setDong(String dong) {
        this.dong = dong;
    }

    public String getRi() {
        return ri;
    }

    public void setRi(String ri) {
        this.ri = ri;
    }

    public String getBunji() {
        return bunji;
    }

    public void setBunji(String bunji) {
        this.bunji = bunji;
    }

}
