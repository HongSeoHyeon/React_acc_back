package kr.co.seoulit.account.sys.base.exception;

@SuppressWarnings("serial")
public class IdNotFoundException extends Exception {
    public IdNotFoundException(String msg) {
        super(msg);
    }
}
