package kr.co.seoulit.account.posting.business.entity;

public class JournalDetailEntity {
}
