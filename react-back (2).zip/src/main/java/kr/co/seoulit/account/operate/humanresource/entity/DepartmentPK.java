package kr.co.seoulit.account.operate.humanresource.entity;


import java.io.Serializable;

public class DepartmentPK implements Serializable {
    private String workplaceCode;
    private String deptCode;
}
