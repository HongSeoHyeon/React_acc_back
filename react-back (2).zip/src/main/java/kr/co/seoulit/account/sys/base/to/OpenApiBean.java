package kr.co.seoulit.account.sys.base.to;

public class OpenApiBean {
	private String sidonm;
	private String co;
	private String no;
	private String so;
	private String tsp;
	private String pm;
	private String voc;
	private String pm2;
	private String nh3;
	
	
	
	
	public String getSidonm() {
		return sidonm;
	}
	public void setSidonm(String sidonm) {
		this.sidonm = sidonm;
	}
	public String getCo() {
		return co;
	}
	public void setCo(String co) {
		this.co = co;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getSo() {
		return so;
	}
	public void setSo(String so) {
		this.so = so;
	}
	public String getTsp() {
		return tsp;
	}
	public void setTsp(String tsp) {
		this.tsp = tsp;
	}
	public String getPm() {
		return pm;
	}
	public void setPm(String pm) {
		this.pm = pm;
	}
	public String getVoc() {
		return voc;
	}
	public void setVoc(String voc) {
		this.voc = voc;
	}
	public String getPm2() {
		return pm2;
	}
	public void setPm2(String pm2) {
		this.pm2 = pm2;
	}
	public String getNh3() {
		return nh3;
	}
	public void setNh3(String nh3) {
		this.nh3 = nh3;
	}
	
	
	
	
	
}
