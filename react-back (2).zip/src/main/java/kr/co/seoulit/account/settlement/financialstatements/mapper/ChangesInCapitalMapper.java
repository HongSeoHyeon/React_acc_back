package kr.co.seoulit.account.settlement.financialstatements.mapper;

public interface ChangesInCapitalMapper {

}
