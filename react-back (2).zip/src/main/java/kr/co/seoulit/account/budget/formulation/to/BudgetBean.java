package kr.co.seoulit.account.budget.formulation.to;

import kr.co.seoulit.account.sys.base.to.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class BudgetBean extends BaseBean {

	private String deptCode;
	private String workplaceCode;
	private String accountInnerCode;
	private String accountPeriodNo;
	private String budgetingCode;
	private String m1Budget;
	private String m2Budget;
	private String m3Budget;
	private String m4Budget;
	private String m5Budget;
	private String m6Budget;
	private String m7Budget;
	private String m8Budget;
	private String m9Budget;
	private String m10Budget;
	private String m11Budget;
	private String m12Budget;
}
