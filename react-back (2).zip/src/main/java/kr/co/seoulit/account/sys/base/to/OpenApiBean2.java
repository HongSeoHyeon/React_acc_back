package kr.co.seoulit.account.sys.base.to;

public class OpenApiBean2 {
	private String dateName;
	private String locdate;
	
	public String getDateName() {
		return dateName;
	}
	public void setDateName(String dateName) {
		this.dateName = dateName;
	}
	public String getLocdate() {
		return locdate;
	}
	public void setLocdate(String locdate) {
		this.locdate = locdate;
	}
	
}
