package kr.co.seoulit.account.budget.formulation.to;

public class BudgetCodeBean {
}
