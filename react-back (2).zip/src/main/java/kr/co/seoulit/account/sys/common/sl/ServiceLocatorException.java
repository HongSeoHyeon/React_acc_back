package kr.co.seoulit.account.sys.common.sl;

@SuppressWarnings("serial")
public class ServiceLocatorException extends RuntimeException {

    public ServiceLocatorException(String message) {

        // TODO Auto-generated constructor stub
        super(message);
    }

}
