package kr.co.seoulit.account.posting.business.mapper;

public interface SlipCancellationOfApprovalMapper {
	
}
