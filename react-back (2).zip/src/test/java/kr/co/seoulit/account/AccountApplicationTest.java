package kr.co.seoulit.account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountApplicationTest {
    @Test
    void contextLoads() {
    }

}
